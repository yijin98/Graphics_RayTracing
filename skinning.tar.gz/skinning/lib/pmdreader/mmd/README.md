libmmd
======

A MikuMikuDance Library in C++