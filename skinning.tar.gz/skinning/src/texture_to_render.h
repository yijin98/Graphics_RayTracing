#ifndef TEXTURE_TO_RENDER_H
#define TEXTURE_TO_RENDER_H

/*
 * This is a placeholder class for Milestone 2
 */
class TextureToRender {
public:
	TextureToRender() {} 
	~TextureToRender() {}
};

#endif
